import 'package:flutter/material.dart';
import 'event.dart';

void main() {
  runApp(HomePage());
}

class HomePage extends StatelessWidget {
  final List<Event> events = [
    Event(
      title: 'Session 0',
      description:
          'An Introduction to web development with the basics of HTML, CSS and Javascript',
      date: DateTime(2023, 7, 6, 14, 0), // Example date and time
    ),
    Event(
      title: 'Session 1',
      description: 'Dart Programming and FLutter Basics',
      date: DateTime(2023, 7, 8, 14, 0), // Example date and time
    ),
    Event(
      title: 'Session 2',
      description: 'Git, Github, UI/UX and using Figma to design an interface',
      date: DateTime(2023, 7, 11, 14, 0), // Example date and time
    ),
    Event(
      title: 'Session 3',
      description: 'App Development with Flutter',
      date: DateTime(2023, 7, 13, 14, 0), // Example date and time
    ),
    Event(
      title: 'Session 4',
      description: 'Introduction to Node.JS, and its applications',
      date: DateTime(2023, 7, 15, 14, 0), // Example date and time
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.deepPurple[900],
          leading: Icon(Icons.menu),
          title: Text('Summer-School : WebOps'),
        ),
        body: ListView.builder(
          itemCount: events.length,
          itemBuilder: (context, index) {
            return Card(
              elevation: 2.5,
              margin: EdgeInsets.fromLTRB(6, 10, 6, 1),
              color: Colors.purple[50],
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              child: ListTile(
                contentPadding: EdgeInsets.fromLTRB(10, 8, 8, 10),
                title: Text(
                  events[index].title,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                subtitle: Text(
                  events[index].description,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 15,
                  ),
                ),
                trailing: Column(
                  children: [
                    Text(
                      "DATE AND TIME",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Color(0xff757474),
                      ),
                    ),
                    Text(
                      events[index].date.toString(),
                      textAlign: TextAlign.right,
                    ),
                  ],
                ),
              ),
            ); //
          },
        ),
      ),
    );
  }
}
