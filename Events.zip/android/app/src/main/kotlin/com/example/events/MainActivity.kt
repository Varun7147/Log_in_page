package com.example.events

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
