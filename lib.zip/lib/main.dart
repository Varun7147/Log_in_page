import 'package:flutter/material.dart';

void main() {
  runApp(LoginPage());
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(resizeToAvoidBottomInset: false,
        backgroundColor: Color.fromARGB(255, 177, 218, 251),
        body: Column(children:[Image.asset(
                  "lib/images/Login_image.jpg",height: 256, width: 490),

      
        
        
        
        Padding(
          padding: EdgeInsets.only(left: 15.0, right: 15.0, bottom: 15.0), 
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              
              SizedBox(height: 49.0),
              Row(
                children: [
                  SizedBox(
                    width: 12,
                  ),
                  Text(
                    'Email',
                    style: TextStyle(
                      fontFamily: 'Calibri',
                      fontWeight: FontWeight.w800,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 7,
              ),
              TextFormField(
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.fromLTRB(20.0, 5.0, 5.0, 10.0),
                  prefixIcon: Icon(Icons.email),
                  prefixIconColor: Colors.black87,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    borderSide: BorderSide(color: Colors.black45, width: 5),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              SizedBox(height: 7.0),
              Row(
                children: [
                  SizedBox(
                    width: 12,
                  ),
                  Text(
                    'Password',
                    style: TextStyle(
                      fontFamily: 'Calibri',
                      fontWeight: FontWeight.w800,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 7,
              ),
              TextFormField(
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.fromLTRB(20.0, 5.0, 5.0, 10.0),
                  prefixIcon: Icon(Icons.person),
                  prefixIconColor: Colors.black87,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    borderSide: BorderSide(color: Colors.black45, width: 2),
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              SizedBox(height: 32.0),
              SizedBox(
                height: 39,
                width: 90,
                child: ElevatedButton(
                  onPressed: () {
                    // Perform login functionality
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color.fromARGB(255, 244, 239, 252),
                    foregroundColor: Colors.purple[900],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(
                        Radius.circular(50),
                      ),
                    ),
                  ),
                  child: Text(
                    'Login',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    "Don't have an account?",
                    style: TextStyle(
                      color: Colors.indigo[900],
                      fontFamily: 'Calibri',
                      fontSize: 19,
                    ),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: Text(
                      'Sign Up',
                      style: TextStyle(
                        color: Color.fromARGB(255, 63, 8, 74),
                        fontSize: 18,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
     ], ),
      ),);
  }
}