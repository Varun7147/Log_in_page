import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.white,
       body: SafeArea( 
        child: Center(
          child: Column(
            children: [




            const SizedBox(height: 50),
            Text('Email', style: TextStyle(fontWeight: FontWeight.w300, fontSize: 17,),),


              const SizedBox(height: 25),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25.0),

              ),

              

            ],
            ),
        ),



       ),
);
  }
}